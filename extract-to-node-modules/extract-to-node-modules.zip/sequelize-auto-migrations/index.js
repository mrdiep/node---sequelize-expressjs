
module.exports = require("./lib/migrate");
